import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private http:HttpClient) { }

  getProjects()
  {
    return this.http.get<any>('assets/data/projects.json')
    .toPromise()
    .then(res => res.data)
    .then(data => { return data; });
  }

  getData()
  {
    return this.http.get<any>('assets/data/sow.json')
    .toPromise()
    .then(res => res.data)
    .then(data => { return data; });
  }
}
