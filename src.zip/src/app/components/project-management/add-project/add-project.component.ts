import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,FormControl,Validators,NgForm} from '@angular/forms'  
import { ProjectService } from '../../../services/project.service'

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {
  addForm:FormGroup;
  constructor(private frmbuilder:FormBuilder,private projectService:ProjectService) {
    this.addForm= frmbuilder.group({  
      sowcode:['',Validators.required],  
      projcode:['',Validators.required],  
      title:['',Validators.required],  
      client:['',Validators.required],
      dtype:['',Validators.required],
      p_type:['',Validators.required],
      status:['',Validators.required]  
    })  
   }

  ngOnInit() {
  }

  postData(addForm:NgForm)  
  {  
    console.log(addForm.value);  
  }  
}
