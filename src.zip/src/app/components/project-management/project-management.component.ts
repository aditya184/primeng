import { Component, OnInit } from '@angular/core';
import {TabMenuModule} from 'primeng/tabmenu';
import {MenuItem} from 'primeng/api';
import { ProjectService } from '../../services/project.service';
import {SelectItem} from 'primeng/api';
import {Router} from '@angular/router'

@Component({
  selector: 'app-project-management',
  templateUrl: './project-management.component.html',
  styleUrls: ['./project-management.component.css']
})
export class ProjectManagementComponent implements OnInit {
  items: MenuItem[];
  activeItem: MenuItem;
  data:any;
  cols:any=[];
  types:SelectItem[];
  display:boolean = false;
  steps: MenuItem[];
  stepsForQuickProject: MenuItem[];
  activeIndex: number = 0;
  activeIndex1: number = 0;
  displayAddProject:boolean = false;
  displayAddQuickProject:boolean = false;
  step1:any=[]
  step2:any=[]
  selectType:SelectItem[];
  buttons:MenuItem[];
  // myMessage = "message from parent";  
  constructor(private router:Router,private projectService:ProjectService) { 
  }

  ngOnInit() {
    this.items = [
      {label: 'All Projects'},
      {label: 'Sent to Client'},
      {label: 'Client Review'},
      {label: 'Pending Allocation'},
      {label: 'Inactive Projects'}
  ];

  this.buttons = [
    {label: 'Add SOW', icon: 'pi pi-plus-circle', command: () => {
        this.showDialog();
    }},
    {label: 'Add Quick Project', icon: 'pi pi-plus-circle', command: () => {
        this.addQuickProject();
    }},
];
  this.step1[0] =0;
  this.step2[0] =0;

  //steps
  this.steps = [{
    label: 'Select Sow',
    command:(event:any)=>{
      console.log(event)
      this.step1[event.index] = event.index;
      // this.step1[event.index] = true;
    }
  },
  {
    label: 'Project Attributes',
    command:(event:any)=>{
      console.log(event.index)
      this.step1[event.index] = event.index;
    }
  },
  {
    label: 'Timeline',
    command:(event:any)=>{
      this.step1[event.index] = event.index;
    }
  },
  {
    label: 'Finance & Management',
    command:(event:any)=>{
      this.step1[event.index] = event.index;
    }
  }]

  this.stepsForQuickProject=[{
      label: 'Select Sow',
      command:(event:any)=>{
        console.log(event.index)
        this.step2[event.index] = event.index;
      }
    },
    {
      label: 'Project Attributes',
      command:(event:any)=>{
        console.log(event.index)
        this.step2[event.index] = event.index;
      }
    }]


  this.cols = [
    { field: 'sow_code', header: 'SOW code' },
    { field: 'proj_code', header: 'Proj. Code' },
    { field: 'short_title', header: 'Short Title' },
    { field: 'client', header: 'Client' },
    { field: 'deliverable_type', header: 'Deliverable Type' },
    { field: 'project_type', header: 'Proj. Type' },
    { field: 'status', header: 'Status' },
    { field: 'createdBy', header: 'Created By' },
    { field: 'createdDate&Time', header: 'Created Date & Time' }
];

  this.types = [
    { label: 'Abstract', value: 'Abstract' },
    { label: 'Manuscript', value: 'Manuscript' }
  ];

  this.selectType = [
    {label:'Select Type', value:null},
    { label: 'Abstract', value: 'Abstract' },
    { label: 'Manuscript', value: 'Manuscript' }
];

    this.getData();
  }

  getData(){
    this.projectService.getProjects().then(res => this.data = res)
  }

  showDialog() {
    this.display = true;
  }

  showDialog1()
  {
    this.displayAddProject = true;
  }

  addQuickProject()
  {
    this.displayAddQuickProject = true;
  }

  nextStep(index){
    console.log(index)
    this.step2[index+1]= index+1;
    this.activeIndex1 = index+1;
  }

  prevStep(index){
    console.log(index)
    this.step2[index-1]= index-1;
    this.activeIndex1 = index-1;
  }

  filterItem(value){
    console.log(value.toLowerCase())
    if(!value){
        this.getData();
    }
    this.data = Object.assign([], this.data).filter(
       item => console.log(item)
    )
 }

}
