import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {
val1:string ="sp";
display:boolean = true;
display1:boolean = false;
  constructor() { 
  }

  ngOnInit() {
  }

  valueChange(val)
  {
    console.log(val)
    if(val=='sp')
    {
      this.display = true;
      this.display1 = false;
    }
    else if(val=='nsp'){
      this.display1 = true;
      this.display = false;
    }
  }
}
