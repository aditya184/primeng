import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuickProjectAttributesComponent } from './quick-project-attributes.component';

describe('QuickProjectAttributesComponent', () => {
  let component: QuickProjectAttributesComponent;
  let fixture: ComponentFixture<QuickProjectAttributesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuickProjectAttributesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuickProjectAttributesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
