import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-attributes',
  templateUrl: './project-attributes.component.html',
  styleUrls: ['./project-attributes.component.css']
})
export class ProjectAttributesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
