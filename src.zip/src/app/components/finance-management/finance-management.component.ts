import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finance-management',
  templateUrl: './finance-management.component.html',
  styleUrls: ['./finance-management.component.css']
})
export class FinanceManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
